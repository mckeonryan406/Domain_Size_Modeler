function[delta] = delta_calc(data, Ea)

% calculates ln(r/ro) which is referred to here as Delta
% It does so using an input Ea (in kcal/mol!) and using an
% arbitrary value of 25 for ln(Do/a2).


lnDa2 = data(:,2);
TK = data(:,1);
R = 1.987;  % gas constant for kcal/mol
slope = -Ea/(R*10);
Do = 25;

for i = 1:length(lnDa2)
    b = slope*TK(i);
    c = b+Do;
    d = c - lnDa2(i);
    
    delta(i) = d*0.5;
end



