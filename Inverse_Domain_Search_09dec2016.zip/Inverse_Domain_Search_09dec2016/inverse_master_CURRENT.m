% INVERSE DOMAIN SEARCH FOR MDD ANALYSIS

% Created By: Ryan McKeon
% Date: 8 Dec 2016
% Contact: ryan.e.mckeon@dartmouth.edu

% PURPOSE --------------------------------
% This code generates a diffusion domain structure for Multiple Diffusion
% Domain analysis from step heating data (either 4He/3He or Ar/Ar). At 
% present, this code uses a SPHEREICAL diffusion domain only and the
% analytical solution for which is from Farley et al., 2010 G-cubed.  This
% code uses the Bayesian Information Criterion score (BIC) to balance the 
% improvement of a model fit vs. the number of domains used to generate
% said fit.  I.E. is it better to use fewer domains and introduce less 
% to the model?  In the end you can decide, but the results here may
% suprise you.

% HOW THE CODE WORKS ---------------------
% The inverse search reads in observed step heating results (input file
% defined and described below) and kinetic data (also defined and described
% below) and attempt to fit the observed data by creating diffusion
% domains and adjusting their size and proportion of the total gas (i.e.
% the reference non-radiogenic isotope).  This serach uses the r/ro plot of 
% Lovera et al. (1991) JGR -- Here referred to as delta --  to optimize the 
% modeled data with the observed results.  The search is optimized by fitting 
% both the step gas release (F) and the cumulative gas release (Fcum) of the 
% model with the observed results (after Farley and Flowers, 2012 EPSL).
% 
% This search is accomplished in two steps, the first is purely random, the
% second takes the best fit from the random attempts and hones the size and 
% gas fraction of each domain in a systematic fashion.  This code is set up 
% to iterate through attempting to fit the data using a different number of
% domains and for each specific number of domains it tries multiple times
% from scratch to fit the data in order to avoid hammering away for a long 
% time on a local minimum of mistfit or BIC score.

% INPUT DATA FILES -----------------------
obs_data_file = 'data_in_example.txt';  % observed step heating data
kinetic_data_file = 'kinetics_in_example.txt'; % kinetics estimated from observed data


% KNOBS ----------------------------------
% How many Domains do you want to try fitting?
domain_range = [1,2,3,4,5,7,10]; % You can give it a lot to try
%domain_range = [3] % or just one

% How many times to try each domain?
n_model_loops = 5; % number of times to run full model to avoid local minima in search

% no real need to change the values below 
n_hone_loops = 30; % total number of honing loops after random search start
adjust_loops = 50; % number of pairs of domains to adjust for gas fraction on each hone loop
size_adjuster = 1.4; % magnitude of size adjustment per step in loop
gas_adjuster = 1.15; % magnitude of gas adjustment per step in loop

% I/O: ------------------------------------

% Inputs
% obs_data_file = observed data array
%   col 1 = step #
%   col 2 = Temp (deg C)
%   col 3 = time (hr)
%   col 4 = Fcum observed
%   col 5 = 10000/K
%   col 6 = lnDa2 observed
%   col 7 = ln(r/ro) observed ---  here referred to as delta observed

% kinetic_data_file = array of observed kinetics that control modeling
%   value 1 = Ea in kcal/mol!
%   value 2 = lnDoa2 ---> important because this ties the reference size
%   value 3 = reference domain size for these kinetics (use 1 unless you know otherwise)

% domains_in = array of domain data for modeling F -- only needed if you
% want to forward model something -- in which case you would want to just
% use master_domain.m
%   col 1 = size of domain relative to ref_a
%   col 2 = gas fraction contained in domain

% Outpus: 
% generates an Excel file called "modeled_data_OUT.xls", which stores the results
% from the model iteration with the lowest BIC score for the whole modeling session.  
% I.E. if you try a wide range of differnt numbers of domains, only one single combination of 
% goodness of fit with allowed complexity will be saved.  This file has the following structure:

%   row 1 = misfit score, BIC (bayesian information criterion), ndomains, Ea, lnDo/a2, slope
%   row 2 = Gas fraction of each domain modeled
%   row 3 = Relative domain size for each domain modeled
%   row 4 - n      
%       col 1 = step number
%       col 2 = Temp (deg C)
%       col 3 = time (hr)
%       col 4 = Fcum modeled
%       col 5 = 10000/K
%       col 6 = lnDa2 modeled
%       col 7 = delta modeled --> ln(r/ro) in Lovera-speak
%       col 8 = delta OBSERVED --> included for plotting comparison
%       col 9 = lnDa2 OBSERVED --> included for plotting
%       col 10 = Fcum OBSERVED --> included for plotting

% Also generates plots -- The running Delta plot shows the progress of each
% iteration as the fit is improved.  At the conclusion of the code, a pdf with
% plots of Delta (model vs. observed), arrhenius data (observed with modeled and
% reference domains) and a comparison of best BIC scores for different numbers of
% domains are saved as "domain_model_plots.pdf"


% On to the code!

% block annoying warnings from the command window
warning('off','all')
warning

% set up figure window for evolving Delta plot
FigHandle = figure('Position', [100, 100, 450, 350]);

BIC_log=[];

for iii = 1:length(domain_range)
    ndomains = domain_range(iii);
    disp('Now modeling observed data using');
    disp(iii);
    disp('Domains');

    % Iterate the full model for a single number of domains to avoid local
    % minima
    for ii = 1:n_model_loops

        % Start search with random domain structure

        n_rand_loops = 100;
        BIC_log_rand = zeros(n_rand_loops,1);
        gas_rand = zeros(n_rand_loops,ndomains+1);
        for i = 1:n_rand_loops
            domains_in = create_domain_structure(ndomains);

            % checking gas faction 
            gas_total = sum(domains_in(:,2));
            gas_rand(i,1:ndomains)=domains_in(:,2);
            gas_rand(i,ndomains+1) = gas_total;


            domain_model_out = master_domain(obs_data_file,kinetic_data_file,domains_in);
            BIC_log_rand(i) = domain_model_out(1,2);
            if i == 1
                BIC_best = domain_model_out(1,2); % if it is the first loop, store the BIC
                domain_model_out_best = domain_model_out; % store the domain structure too
            else
                BIC_current = domain_model_out(1,2); % for the rest of the loops compare the BIC of the current loop with the best and store it
                if BIC_current < BIC_best
                    BIC_best = BIC_current;
                    domain_model_out_best = domain_model_out; % store the domain structure too
                end
            end
           figure1 = make_delta_plot(obs_data_file, domain_model_out_best);
           drawnow;
           rand_best_domains = domain_model_out_best(2:3,1:ndomains); % store the best rand result
        end
        disp('Model Iteration Number')
        disp(ii)
        disp('')
        disp('Done with Random Domains')
        disp('Now Honing In on Delta fit...')
        disp('Current Best BIC is')
        disp(BIC_best)

        % Now Hone the best attempt from the random search --> use
        % domain_model_out_best


        %BIC_hone_log_size = zeros(adjust_loops,ndomains,n_hone_loops);
        %BIC_hone_log_gas = zeros(adjust_loops,ndomains,n_hone_loops);


        for z = 1:n_hone_loops

            % first hone in on domain size
            for i = 1:ndomains
                adjuster = 0.01; % how you are modifying the size on the first loop
                for j = 1:adjust_loops
                    domains_in = domain_model_out_best(2:3,1:ndomains);  % grab the current best domain structure 
                    domains_in(1,i) = domains_in(1,i) * adjuster; % change the size of one domain
                    domains_adjusted = transpose(domains_in);  % transpose domains_in for master_domain function

                    % now run the model for the hone iteration and compare the results
                    % to the current best domain structure
                    domain_model_out = master_domain(obs_data_file,kinetic_data_file,domains_adjusted);

                    BIC_current = domain_model_out(1,2);  % get the BIC score of the loop that just ran
                    %BIC_hone_log_size(j,i,z) = BIC_current; % log the hone results

                    % now compare it to the best BIC score
                    if BIC_current < BIC_best
                        BIC_best = BIC_current; % store the current if it is better than the best so far
                        domain_model_out_best = domain_model_out; % store the domain structure too
                        disp(BIC_best)
                    end

                    adjuster = adjuster * size_adjuster; % increment the adjustment

                end
                figure1 = make_delta_plot(obs_data_file, domain_model_out_best);
                drawnow;
            end

            % Now hone in on the Gas Fraction -- obviously doesn't work for
            % 1 domain case.
            
            if ndomains ~= 1

                % Randomly select 2 domains, sum the gas in these domains, then split
                % the gas between the two domains in a systematic way scaling from 0.02
                % to 1.0 of the total gas of the two domains going to one or the other
                % domain.
                gas_hone = zeros(adjust_loops,ndomains+1,ndomains);

                for i = 1:ndomains

                    % Pick two domains to monkey with
                    domains_in = domain_model_out_best(2:3,1:ndomains);  % grab the current best domain structure 
                    test = 0;
                    while test == 0  % check to make sure you grabbed a different domain
                        which_domain = randi(ndomains,1,2);  % randomly select two domains to monkey with
                        if which_domain(1) - which_domain(2) == 0
                            test = 0;
                        elseif which_domain(1) - which_domain(2) ~= 0
                            test = 1;
                        end
                    end

                    % Now do the systematic adjustment of the combined gas of the two
                    % domains

                    adjuster = 0.02; % how you are modifying the gas allocation on the first loop
                    for j = 1:adjust_loops
                        % now sum the gas in the two domains
                        adjust_sum = domains_in(2,which_domain(1)) + domains_in(2,which_domain(2));

                        domains_in(2,which_domain(1)) = adjust_sum * adjuster; % change the gas fraction of one domain
                        domains_in(2,which_domain(2)) = adjust_sum * (1-adjuster);  % change the gas fraction of the other domain

                        %checking gas fraction
                        gas_total = sum(domains_in(2,:));
                        gas_hone(j,1:ndomains,i)=domains_in(2,:);
                        gas_hone(j,ndomains+1,i) = gas_total;

                        %domains_in(2,:)= domains_in(2,:)/sum(domains_in(2,:)); % re-normalize so the sum of the gas fractions = 1, just in case.
                        domains_adjusted = transpose(domains_in);   % transpose domains_in for master_domain function

                        % now run the model for the hone iteration and compare the results
                        % to the current best domain structure
                        domain_model_out = master_domain(obs_data_file,kinetic_data_file,domains_adjusted);

                        BIC_current = domain_model_out(1,2);  % get the BIC score of the loop that just ran
                        %BIC_hone_log_gas(j,i,z) = BIC_current; % log the hone results

                        % now compare it to the best BIC score
                        if BIC_current < BIC_best
                            BIC_best = BIC_current; % store the current if it is better than the best so far
                            domain_model_out_best = domain_model_out; % store the domain structure too
                            disp(BIC_best)
                        end

                        adjuster = adjuster + 0.02; % increment the adjustment

                    end
                end
            end
            figure1 = make_delta_plot(obs_data_file, domain_model_out_best);
            drawnow;
            
        end

        % Compare the BIC score for each full model iteration, keep the best
        if ii == 1
            best_current_model = domain_model_out_best;  % if it is the first loop, store the result
        else
            BIC_stored = best_current_model(1,2);       % otherwise, compare the current BIC iteration with the stored BIC iteration
            BIC_current_model = domain_model_out_best(1,2);
            if BIC_current_model < BIC_stored
                best_current_model = domain_model_out_best;
            end
        end
    end
    
    BIC_log(iii,1) = ndomains;
    BIC_log(iii,2) = best_current_model(1,2);
    BIC_log(iii,3) = best_current_model(1,1);
    
    % Compare the BIC score for each full model iteration, keep the best
    if iii == 1
        best_domain_model = best_current_model;  % if it is the first loop, store the result
    else
        BIC_stored = best_domain_model(1,2);       % otherwise, compare the current BIC iteration with the stored BIC iteration
        BIC_current_model = best_current_model(1,2);
        if BIC_current_model < BIC_stored
            best_domain_model = best_current_model;
        end
    end
end

domain_model_out_best = best_domain_model;  % put the best model result into the correct variable

% calcuate domain properties for output
domain_model_out_best = calc_domain_properties(kinetic_data_file, domain_model_out_best);

% Make arrhenius plot and other output plots with observed data and modeled domains

FigHandle = figure('Position', [100, 100, 900, 800]);
figure2 = make_final_plots(domain_model_out_best, BIC_log);



save modeled_data_OUT.xls domain_model_out_best -ascii -tabs
saveas(FigHandle,'domain_model_plots.pdf');


disp('----- Finished -----')



